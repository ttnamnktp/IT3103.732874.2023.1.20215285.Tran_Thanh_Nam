package Lab02.AimsProject.hust.soict.itep.aims.media;

public interface Playable {
    void play();
}