package Lab02.AimsProject.hust.soict.itep.cart;

import Lab02.AimsProject.hust.soict.itep.cart.Cart;
import Lab02.AimsProject.hust.soict.itep.disc.DigitalVideoDisc;

import java.util.Scanner;
public class CartTest {
    public static void main(String[] args) {
        // Create new cart
        Cart cart = new Cart();

        // Create new DVD objects and add them to the cart
        DigitalVideoDisc dvd1 = new DigitalVideoDisc ("The Lion King","Animation", "Roger Allers", 87, 19.95f);
        cart.addDigitalVideoDisc (dvd1);
        DigitalVideoDisc dvd2 = new DigitalVideoDisc ( "Star Wars", "Science Fiction","George Lucas",  87, 24.95f);
        cart.addDigitalVideoDisc (dvd2);
        DigitalVideoDisc dvd3= new DigitalVideoDisc ( "Aladin","Animation", 18.994);
        cart.addDigitalVideoDisc (dvd3);

        // Test printing method
        cart.print();

        // Test searching method

        int choice = -1;
        while (choice != 0 && choice != 1) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter 0 for searching by id, 1 for seaching by title:");
            choice = scanner.nextInt();
        }
        if (choice == 0) {
            cart.searchById();
        }
        else if (choice == 1) {
            cart.searchByTitle();
        }
    }
}
