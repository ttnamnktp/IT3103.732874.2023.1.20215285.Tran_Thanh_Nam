package Lab01;

public class Ex1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("Toi la Tran Thanh Nam\nToi nam nay 20 tuoi\t sinh nam 2003");
    }
}
