package Lab01;

// Example 2: FirstDialog.java Z

import javax.swing.JOptionPane;
public class FirstDialog{
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,
                "Hello world! How are you?\nI'm Tran Thanh Nam");
        System.exit(0);
    }
}